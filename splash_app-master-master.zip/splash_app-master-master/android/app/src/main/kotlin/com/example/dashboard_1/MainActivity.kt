package com.splash.flare

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
