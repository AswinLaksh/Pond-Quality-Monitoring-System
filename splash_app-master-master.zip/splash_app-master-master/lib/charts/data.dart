import 'package:flutter/material.dart';

class Data {
  final OxygenLevel;
  final tds;
  final Temperature;
  final ph;

  Data(
      {required this.OxygenLevel,
      required this.tds,
      required this.Temperature,
      required this.ph});
  factory Data.fromJson(Map<String, dynamic> json) {
    return Data(
        OxygenLevel: json['Oxygen level'],
        tds: json['TDS'],
        Temperature: json['Temperature'],
        ph: json['pH']);
  }
}
