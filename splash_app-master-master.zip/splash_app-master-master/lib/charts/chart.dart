import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import '../helper/back.dart';
import '../theme/theme.dart';

class chart extends StatefulWidget {
  chart(
      {super.key,
      required this.wanted,
      required this.last,
      required this.sider});
  final String wanted;
  final String sider;
  final last;

  @override
  State<chart> createState() => _chartState();
}

class _chartState extends State<chart> {
  String timestan = 'hour';
  var time = '8:30 PM';

  late ChartSeriesController controller;
  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;

    final themeProvider = Provider.of<ThemeProvider>(context);
    Color color = themeProvider.isDark ? Colors.white : Colors.black;
    return Scaffold(
      body: SafeArea(
        child: Container(
          padding: EdgeInsets.only(
              top: height * 0.01, left: width * 0.02, right: width * 0.02),
          child: StreamBuilder(
            stream: FirebaseDatabase.instance.ref("quality/2-push").onValue,
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                final found = snapshot.data!.snapshot.children.toList();
                final list = [];
                found.forEach((element) {
                  list.add(element.value);
                });

                final li = list.sublist(found.length - 11);
                if (widget.wanted == 'ph level') {
                  print('yes');
                  for (var i in li) {
                    print(i);
                  }
                }
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    back(width: width),
                    Container(
                      margin: EdgeInsets.only(top: height * 0.015),
                      alignment: Alignment.center,
                      child: Text(
                        widget.wanted == 'TDS'
                            ? 'SALINITY'
                            : widget.wanted.toUpperCase(),
                        style: TextStyle(
                            fontSize: width * 0.07,
                            fontWeight: FontWeight.w600),
                      ),
                    ),
                    shifter(width, height, color, themeProvider.isDark),
                    lastvalue(width, height, widget.last, widget.sider),
                    Padding(
                      padding: EdgeInsets.only(left: width * 0.04),
                      child: Text(
                        'STATS',
                        style: TextStyle(
                            fontSize: width * 0.05,
                            fontWeight: FontWeight.w500,
                            color: Colors.grey),
                      ),
                    ),
                    Expanded(
                      child: Container(
                        margin: EdgeInsets.only(top: height * 0.015),
                        padding: EdgeInsets.all(20),
                        child: Center(
                          child: SfCartesianChart(
                            primaryXAxis: CategoryAxis(),
                            primaryYAxis: NumericAxis(),
                            tooltipBehavior: TooltipBehavior(
                              enable: true,
                              textStyle: TextStyle(color: color),
                              tooltipPosition: TooltipPosition.auto,
                              builder: (data, point, series, pointIndex,
                                  seriesIndex) {
                                return Container(
                                  padding: EdgeInsets.all(5),
                                  child: Text(
                                    widget.wanted == 'ph level'
                                        ? data["pH"].toString()
                                        : data[widget.wanted].toString(),
                                    style: TextStyle(color: color),
                                  ),
                                );
                              },
                            ),
                            series: <ChartSeries>[
                              ColumnSeries<dynamic, num>(
                                borderRadius: BorderRadius.circular(6),
                                enableTooltip: true,
                                gradient: LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Color.fromARGB(255, 82, 177, 255),
                                      Color.fromARGB(255, 0, 140, 255)
                                    ]),
                                // onRendererCreated:
                                //     (ChartSeriesController controller) {
                                //   controller = controller;
                                // },
                                dataSource: li,
                                xValueMapper: (i, _) {
                                  return li.indexOf(i);
                                },
                                yValueMapper: (i, _) {
                                  if (i[widget.wanted].runtimeType == String) {
                                    return 10;
                                  } else if (widget.wanted == 'ph level') {
                                    return i['pH'];
                                  } else {
                                    return i[widget.wanted];
                                  }
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                );
              } else {
                return Center(
                  child: LoadingAnimationWidget.beat(
                    color: color,
                    size: 200,
                  ),
                );
              }
            },
          ),
        ),
      ),
    );
  }

  Container lastvalue(double width, double height, var last, var unit) {
    return Container(
      width: width,
      margin: EdgeInsets.only(
          top: height * 0.05,
          left: width * 0.04,
          right: width * 0.04,
          bottom: height * 0.05),
      decoration:
          BoxDecoration(border: Border(bottom: BorderSide(color: Colors.grey))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Last Value : ${last} ${unit}',
            style:
                TextStyle(fontSize: width * 0.05, fontWeight: FontWeight.w600),
          ),
          SizedBox(
            height: height * 0.01,
          ),
          Text(
            time,
            style: TextStyle(
                fontSize: width * 0.05,
                fontWeight: FontWeight.w500,
                color: Colors.grey),
          ),
          SizedBox(
            height: height * 0.01,
          ),
        ],
      ),
    );
  }

  Center shifter(double width, double height, Color data, theme) {
    return Center(
        child: Container(
            width: width * 0.625,
            margin: EdgeInsets.only(
              top: height * 0.02,
            ),
            decoration: BoxDecoration(
              color: Color.fromARGB(255, 232, 232, 232),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                GestureDetector(
                  onTap: () => setState(() {
                    timestan = 'hour';
                  }),
                  child: Container(
                      margin: EdgeInsets.only(
                          top: width * 0.01,
                          left: width * 0.01,
                          bottom: width * 0.01),
                      decoration: BoxDecoration(
                          color: timestan == 'hour' ? data : Colors.transparent,
                          borderRadius: BorderRadius.circular(8)),
                      padding: EdgeInsets.all(width * 0.025),
                      child: Text(
                        'Last 24 hours',
                        style: TextStyle(
                            fontSize: width * 0.04,
                            fontWeight: FontWeight.w500),
                      )),
                ),
                GestureDetector(
                  onTap: () => setState(() {
                    timestan = 'day';
                  }),
                  child: Container(
                    margin: EdgeInsets.only(
                        top: width * 0.01,
                        right: width * 0.01,
                        bottom: width * 0.01),
                    decoration: BoxDecoration(
                        color: timestan == 'day' ? data : Colors.transparent,
                        borderRadius: BorderRadius.circular(8)),
                    padding: EdgeInsets.all(width * 0.025),
                    child: Text(
                      'Last 10 days',
                      style: TextStyle(
                          fontSize: width * 0.04, fontWeight: FontWeight.w500),
                    ),
                  ),
                )
              ],
            )));
  }
}
