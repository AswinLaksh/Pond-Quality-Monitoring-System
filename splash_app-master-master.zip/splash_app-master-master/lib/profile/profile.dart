import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../login_page/auth.dart';
import '../theme/theme.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  final User? user = Auth().currentUser;
  TextEditingController _nameController = TextEditingController();
  TextEditingController _phoneController = TextEditingController();
  late DocumentReference currentUser;
  bool _isEdit = false;


  FirebaseFirestore firestore = FirebaseFirestore.instance;
  final CollectionReference usersCollection = FirebaseFirestore.instance
      .collection('users');
  @override
  void initState() {
    super.initState();
    final userId = _firebaseAuth.currentUser!.uid;
    currentUser = FirebaseFirestore.instance.collection('users').doc(userId);
    currentUser.get().then((documentSnapshot) async {
      final collectionRef = FirebaseFirestore.instance.collection('users');
      final documentSnapshot = await collectionRef.doc(userId).get();
      final data = documentSnapshot.data();
      _nameController.text = data!['name'];
      _phoneController.text = data['phone number'];
    });
  }



  @override
  Widget build(BuildContext context) {
    var scrWidth = MediaQuery.of(context).size.width;
    var scrHeight = MediaQuery.of(context).size.height;
    final themeProvider = Provider.of<ThemeProvider>(context);
    final data = !themeProvider.isDark ? Color.fromRGBO(51, 51, 51, 1) : Colors.white;

    return Scaffold(
      body: SingleChildScrollView(
        child: Column(children: [
           SizedBox(
            height: scrHeight/15,
          ),
          const Center(
            child: Text(
              "Profile",
              style: TextStyle(
                fontFamily: 'SF-Pro',
                fontSize: 27,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          SizedBox(
            height: scrHeight/50,
          ),
          const Center(
            child: Image(
              image: AssetImage('asset/icon/profile.png',),
              height: 150,
              width: 150,
            ),
          ),
           SizedBox(
            height: scrHeight/50,
          ),
          const Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 25.0, bottom: 5),
              child: Text(
                "Name",
                style: TextStyle(
                  fontSize: 15,
                  color: Color(0xff938D8D),
                  fontFamily: 'SF-Pro',
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          Container(
            height: scrHeight / 15,
            width: scrWidth / 1.12,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15.0),
              color: data,
            ),
            child: Padding(
              padding: EdgeInsets.fromLTRB(20.0, 16.0, 0, 0),
              child: TextFormField(
                controller: _nameController,
                enabled: _isEdit,
                style: TextStyle(
                  fontFamily: 'SF-Pro',
                  fontWeight: FontWeight.w600,
                  fontSize: 16,

                ),
              ),
            ),
          ),
          SizedBox(
            height: scrHeight/30,
          ),
          const Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 25.0, bottom: 5),
              child: Text(
                "Email",
                style: TextStyle(
                  fontSize: 15,
                  color: Color(0xff938D8D),
                  fontFamily: 'SF-Pro',
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          Container(
            height: scrHeight / 15,
            width: scrWidth / 1.12,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15.0),
              color: data,
            ),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20.0, 16.0, 0, 0),
              child: Text(
                user?.email ?? 'User email',
                style: const TextStyle(
                  fontFamily: 'SF-Pro',
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                ),
              ),
            ),
          ),
          SizedBox(
            height: scrHeight/30,
          ),
          const Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 25.0, bottom: 5),
              child: Text(
                "Phone Number",
                style: TextStyle(
                  fontSize: 15,
                  color: Color(0xff938D8D),
                  fontFamily: 'SF-Pro',
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          Container(
            height: scrHeight / 15,
            width: scrWidth / 1.12,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15.0),
              color: data,
            ),
            child: Padding(
              padding: EdgeInsets.fromLTRB(20.0, 16.0, 0, 0),
              child: TextFormField(
                controller: _phoneController,
                enabled: _isEdit,
                style: TextStyle(
                  fontFamily: 'SF-Pro',
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                ),
              ),
            ),
          ),
          SizedBox(
              height: scrHeight/25
          ),
          Container(
            height: 41,
            width: scrWidth / 2.5,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10.0),
              color: themeProvider.isDark? Colors.black54:Color(0xff3C3C43),
            ),
            child: MaterialButton(
              onPressed: (){
                saveData();
                setState(() {
                  _isEdit = !_isEdit;
                });
              },
              child: Text(
                  _isEdit ? "Save" : "Edit",
                style: TextStyle(
                  fontFamily: 'SF-Pro',
                  fontWeight: FontWeight.w600,
                  fontSize: 18,
                ),
              ),
            ),
          ),
          SizedBox(
            height: scrHeight / 25,
          ),
          Container(
            height: 41,
            width: scrWidth / 2.5,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10.0),
              color: themeProvider.isDark? Colors.black54:Color(0xff3C3C43),
            ),
            child: MaterialButton(
              onPressed: signOut,
              child: Text(
                "Logout",
                style: TextStyle(
                  fontFamily: 'SF-Pro',
                  fontWeight: FontWeight.w600,
                  fontSize: 18,
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Future<void> signOut() async {
    await _firebaseAuth.signOut();
  }
  void saveData() async {
    String name = _nameController.text;
    String phoneNumber = _phoneController.text;
    String email = user?.email ?? 'User email';

    var User = FirebaseAuth.instance.currentUser;
    String? userID = User?.uid;

    Map<String, dynamic> data = {
      'name': name,
      'phone number': phoneNumber,
      'email': email,
    };

    await FirebaseFirestore.instance
        .collection('users')
        .doc(userID) // replace userID with the user's ID or a unique identifier
        .set(data);
  }
}